def test(ctx):
    inputs = ctx.inputs
    print('Hello string: '.format(inputs['a']))
    ctx.outputs['result'] = inputs['a'] + "c"
