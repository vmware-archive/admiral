function handler($context)
{
    $result = $inputs.a + 1
    $context.outputs = @{"result" = $result} | ConvertTo-JSON
}
