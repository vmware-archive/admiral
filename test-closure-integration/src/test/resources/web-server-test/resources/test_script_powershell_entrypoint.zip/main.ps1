$result = $inputs.a + 1
$context.outputs = @{"result" = $result} | ConvertTo-JSON
Add-Content 'output.txt' $context.outputs
