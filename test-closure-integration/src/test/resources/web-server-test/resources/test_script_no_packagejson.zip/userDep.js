var moment = require('moment');


function test() {
    console.log('Hello from dependent script at time: ' + moment().valueOf());
}

module.exports.test = test;