function test($context)
{
    $result = $inputs.a + 'c'
    $context.outputs = @{"result" = $result} | ConvertTo-JSON
}
