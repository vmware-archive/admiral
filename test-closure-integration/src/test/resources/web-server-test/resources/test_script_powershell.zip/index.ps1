$result = $inputs.a + 'c'
$context.outputs = @{"result" = $result} | ConvertTo-JSON
Add-Content 'output.txt' $context.outputs
