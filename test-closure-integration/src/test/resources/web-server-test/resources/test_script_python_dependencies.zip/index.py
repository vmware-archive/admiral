import billiard
               
def f():
    print('ok!')
                
def test(context):
    inputs = context.inputs
    print('Hello number  {}'.format(inputs['a']))
    context.outputs['result'] = inputs['a'] + 1
                
    billiard.forking_enable(1)
    p = billiard.Process(target = f)
    p.start()
    while p.is_alive():
        pass
                
