var ugli = require('uglify-js');
var userDep = require('./userDep.js')
var child_process = require('child_process');

module.exports = function(ctx) {
    console.log('Hello string: ' + ctx.inputs.a);
    console.log('Hello from parent user script...');
    userDep.test();
    ctx.outputs.result = ctx.inputs.a.concat("c");
};
