package testpackage;
              
public class Sum {
    public static int sum(int a, int b) {
        int result = a + b;
        return result;
    }
}
