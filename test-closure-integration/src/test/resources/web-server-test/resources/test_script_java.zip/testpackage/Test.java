package testpackage;

import java.util.Map;

import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.vmware.admiral.closure.runtime.Context;
              
public class Test {
    public void test(Context context) {
	Map<String, Object> inputs = context.getInputs();
        int a = ((JsonPrimitive) inputs.get("a")).getAsInt();
        int b = ((JsonPrimitive) inputs.get("b")).getAsInt();
        int result = Sum.sum(a, b);
        System.out.println(result);
        context.setOutput("result", result);
    }
}
