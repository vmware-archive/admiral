import com.google.gson.JsonObject;
import com.vmware.admiral.closure.Context;
              
public class Test {
    public void test(Context context) {
        int a = context.inputs.get("a").getAsInt();
        int b = context.inputs.get("b").getAsInt();
        int result = Sum.sum(a, b);
        System.out.println(result);
        context.outputs.addProperty("result", result);
    }
}
