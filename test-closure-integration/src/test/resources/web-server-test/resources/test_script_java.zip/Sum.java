import com.google.gson.JsonObject;
import com.vmware.admiral.closure.Context;
              
public class Sum {
    public static int sum(int a, int b) {
        int result = a + b;
        return result;
    }
}
